import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import api from "../services/api";
import { useNotification } from "../context/NotificationContext";
import { useAuth } from "../context/AuthContext";

export default function ExceptionHandling() {
    const [cases, setCases] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedCase, setSelectedCase] = useState(null);
    const [filter, setFilter] = useState('PENDING'); // PENDING, UNDER_REVIEW, RESOLVED, CLOSED
    const [typeFilter, setTypeFilter] = useState('all'); // all, ESCALATED_REJECTION, DISPUTED_CLAIM, AGENT_MISCONDUCT
    const { notify } = useNotification();
    const { user } = useAuth();



    const fetchCases = useCallback(() => {
        setLoading(true);
        const endpoint = filter === 'all' ? '/admin/exceptions' : `/admin/exceptions/status/${filter}`;
        api.get(endpoint)
            .then(r => {
                setCases(r.data);
                setLoading(false);
            })
            .catch(err => {
                console.error(err);
                notify("Failed to load exception cases", "error");
                setLoading(false);
            });
    }, [filter, notify]);

    useEffect(() => {
        fetchCases();
    }, [fetchCases]);

    const filteredCases = typeFilter === 'all'
        ? cases
        : cases.filter(c => c.caseType === typeFilter);

    const pendingCount = cases.filter(c => c.status === 'PENDING').length;
    const underReviewCount = cases.filter(c => c.status === 'UNDER_REVIEW').length;
    const resolvedCount = cases.filter(c => c.status === 'RESOLVED').length;

    return (
        <div style={{ padding: '36px 40px', maxWidth: 1400, margin: '0 auto' }}>

            {/* ── Hero Header ── */}
            <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} style={{ marginBottom: 32 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <span className={`badge badge-${user?.role === 'SUPER_ADMIN' ? 'super-admin' : 'company-admin'}`} style={{ fontSize: '0.7rem' }}>
                        {user?.role === 'SUPER_ADMIN' ? '⚡ SUPER ADMIN' : '🏢 COMPANY ADMIN'}
                    </span>
                    <span style={{
                        fontSize: '0.7rem', fontWeight: 700, color: '#10b981',
                        background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)',
                        padding: '3px 10px', borderRadius: 20, display: 'flex', alignItems: 'center', gap: 5
                    }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981', display: 'inline-block' }} />
                        Real-time
                    </span>
                </div>
                <h1 style={{ margin: 0, fontSize: '2rem', fontWeight: 800, color: 'var(--text-main)', fontFamily: "'Space Grotesk',sans-serif" }}>
                    ⚖️ Exception <span className="text-gradient">Handling</span>
                </h1>
                <p style={{ margin: '6px 0 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                    Manage escalated rejections, disputed claims, and agent misconduct cases.
                </p>
                <div style={{ height: 1, background: 'linear-gradient(90deg, rgba(245,158,11,0.5), transparent)', marginTop: 16 }} />
            </motion.div>

            {/* Status Filter Tabs */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
                <FilterTab
                    active={filter === 'PENDING'}
                    onClick={() => setFilter('PENDING')}
                    label="Pending"
                    count={pendingCount}
                    color="#eab308"
                />
                <FilterTab
                    active={filter === 'UNDER_REVIEW'}
                    onClick={() => setFilter('UNDER_REVIEW')}
                    label="Under Review"
                    count={underReviewCount}
                    color="#3b82f6"
                />
                <FilterTab
                    active={filter === 'RESOLVED'}
                    onClick={() => setFilter('RESOLVED')}
                    label="Resolved"
                    count={resolvedCount}
                    color="#22c55e"
                />
            </div>

            {/* Type Filter */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 30 }}>
                <TypeFilterButton
                    active={typeFilter === 'all'}
                    onClick={() => setTypeFilter('all')}
                    label="All Types"
                    icon="📋"
                />
                <TypeFilterButton
                    active={typeFilter === 'ESCALATED_REJECTION'}
                    onClick={() => setTypeFilter('ESCALATED_REJECTION')}
                    label="Escalations"
                    icon="📢"
                />
                <TypeFilterButton
                    active={typeFilter === 'DISPUTED_CLAIM'}
                    onClick={() => setTypeFilter('DISPUTED_CLAIM')}
                    label="Disputes"
                    icon="⚠️"
                />
                <TypeFilterButton
                    active={typeFilter === 'AGENT_MISCONDUCT'}
                    onClick={() => setTypeFilter('AGENT_MISCONDUCT')}
                    label="Misconduct"
                    icon="🚫"
                />
            </div>

            {/* Cases Grid */}
            {loading ? (
                <div className="grid">
                    {Array.from({ length: 6 }).map((_, i) => (
                        <div key={i} className="card" style={{ minHeight: 250 }}>
                            <div className="skeleton" style={{ height: 20, width: "60%", marginBottom: 10 }}></div>
                            <div className="skeleton" style={{ height: 40, width: "80%", marginBottom: 20 }}></div>
                        </div>
                    ))}
                </div>
            ) : filteredCases.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: 60 }}>
                    <div style={{ fontSize: '3rem', marginBottom: 20 }}>✅</div>
                    <h3>No {filter.toLowerCase()} cases</h3>
                    <p style={{ opacity: 0.7 }}>All clear! No exceptions to handle.</p>
                </div>
            ) : (
                <div className="grid">
                    {filteredCases.map((exCase, index) => (
                        <ExceptionCaseCard
                            key={exCase.caseId}
                            exCase={exCase}
                            index={index}
                            onClick={() => setSelectedCase(exCase)}
                        />
                    ))}
                </div>
            )}

            {/* Case Detail Modal */}
            {selectedCase && (
                <ExceptionCaseModal
                    exCase={selectedCase}
                    onClose={() => setSelectedCase(null)}
                    onUpdate={fetchCases}
                    adminId={user?.id}
                />
            )}
        </div>
    );
}

function FilterTab({ active, onClick, label, count, color }) {
    return (
        <button
            onClick={onClick}
            style={{
                padding: '10px 20px',
                borderRadius: 8,
                border: active ? `2px solid ${color}` : '1px solid var(--card-border)',
                background: active ? `${color}10` : 'transparent',
                color: active ? color : 'var(--text-main)',
                fontWeight: active ? 700 : 500,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: 8
            }}
        >
            {label}
            <span style={{
                background: active ? color : 'var(--card-border)',
                color: active ? 'white' : 'var(--text-main)',
                padding: '2px 8px',
                borderRadius: 12,
                fontSize: '0.75rem',
                fontWeight: 700
            }}>
                {count}
            </span>
        </button>
    );
}

function TypeFilterButton({ active, onClick, label, icon }) {
    return (
        <button
            onClick={onClick}
            style={{
                padding: '8px 16px',
                borderRadius: 8,
                border: active ? '2px solid var(--primary)' : '1px solid var(--card-border)',
                background: active ? 'var(--primary)20' : 'transparent',
                color: active ? 'var(--primary)' : 'var(--text-main)',
                fontWeight: active ? 700 : 500,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: 6
            }}
        >
            {icon} {label}
        </button>
    );
}

function ExceptionCaseCard({ exCase, index, onClick }) {
    const getCaseTypeColor = (type) => {
        switch (type) {
            case 'ESCALATED_REJECTION': return '#eab308';
            case 'DISPUTED_CLAIM': return '#ef4444';
            case 'AGENT_MISCONDUCT': return '#dc2626';
            default: return '#9ca3af';
        }
    };

    const getCaseTypeIcon = (type) => {
        switch (type) {
            case 'ESCALATED_REJECTION': return '📢';
            case 'DISPUTED_CLAIM': return '⚠️';
            case 'AGENT_MISCONDUCT': return '🚫';
            default: return '📋';
        }
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'CRITICAL': return '#dc2626';
            case 'HIGH': return '#ef4444';
            case 'MEDIUM': return '#eab308';
            case 'LOW': return '#22c55e';
            default: return '#9ca3af';
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="card"
            style={{
                cursor: 'pointer',
                borderLeft: `4px solid ${getPriorityColor(exCase.priority)}`,
                position: 'relative',
                background: exCase.isUrgent ? 'linear-gradient(to right, rgba(239,68,68,0.05), rgba(255,255,255,0.02))' : 'rgba(255,255,255,0.02)',
                transition: 'all 0.2s ease',
                display: 'flex', flexDirection: 'column'
            }}
            onClick={onClick}
            whileHover={{ y: -4, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }}
        >
            {/* Priority Badge */}
            {exCase.isUrgent ? (
                <div style={{
                    position: 'absolute',
                    top: 12,
                    right: 12,
                    background: '#ef4444',
                    color: 'white',
                    padding: '4px 10px',
                    borderRadius: 12,
                    fontSize: '0.7rem',
                    fontWeight: 800,
                    boxShadow: '0 0 10px rgba(239,68,68,0.4)',
                    display: 'flex', alignItems: 'center', gap: 4
                }}>
                    <span style={{ animation: 'pulse 2s infinite' }}>🚨</span> URGENT
                </div>
            ) : (
                <div style={{
                    position: 'absolute', top: 12, right: 12, display: 'flex', gap: 6
                }}>
                    <div style={{
                        padding: '3px 8px', borderRadius: 12, fontSize: '0.65rem', fontWeight: 800,
                        background: `${getPriorityColor(exCase.priority)}15`,
                        color: getPriorityColor(exCase.priority), border: `1px solid ${getPriorityColor(exCase.priority)}40`
                    }}>
                        {exCase.priority}
                    </div>
                </div>
            )}

            {/* Case Type */}
            <div style={{ marginBottom: 15, marginTop: exCase.isUrgent ? 30 : 0 }}>
                <div style={{
                    display: 'inline-flex', alignItems: 'center', gap: 6,
                    background: `${getCaseTypeColor(exCase.caseType)}10`,
                    color: getCaseTypeColor(exCase.caseType),
                    padding: '5px 10px',
                    borderRadius: 8,
                    fontSize: '0.75rem',
                    fontWeight: 800,
                    marginBottom: 10,
                    border: `1px solid ${getCaseTypeColor(exCase.caseType)}30`
                }}>
                    <span>{getCaseTypeIcon(exCase.caseType)}</span>
                    <span style={{ letterSpacing: '0.05em' }}>{exCase.caseType.replace('_', ' ')}</span>
                </div>
                <h3 style={{ margin: 0, fontSize: '1.05rem', color: 'var(--text-main)', lineHeight: 1.4 }}>{exCase.title}</h3>
            </div>

            {/* Parties Involved */}
            <div style={{ marginBottom: 15, padding: 10, background: 'rgba(0,0,0,0.03)', borderRadius: 8 }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, opacity: 0.6, marginBottom: 8 }}>
                    PARTIES INVOLVED
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: '0.85rem' }}>
                    <div>
                        <div style={{ opacity: 0.6 }}>User</div>
                        <div style={{ fontWeight: 600 }}>{exCase.userName || 'N/A'}</div>
                    </div>
                    <div>
                        <div style={{ opacity: 0.6 }}>Agent</div>
                        <div style={{ fontWeight: 600 }}>{exCase.agentName || 'N/A'}</div>
                    </div>
                </div>
                {exCase.policyName && (
                    <div style={{ marginTop: 8 }}>
                        <div style={{ opacity: 0.6, fontSize: '0.75rem' }}>Policy</div>
                        <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{exCase.policyName}</div>
                    </div>
                )}
            </div>

            {/* Description Preview */}
            <div style={{ marginBottom: 15 }}>
                <div style={{ fontSize: '0.85rem', lineHeight: 1.4, opacity: 0.8 }}>
                    {exCase.description?.substring(0, 100) || 'No description'}
                    {exCase.description?.length > 100 && '...'}
                </div>
            </div>

            {/* Metadata */}
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
                <span style={{
                    background: `${getPriorityColor(exCase.priority)}20`,
                    color: getPriorityColor(exCase.priority),
                    padding: '4px 8px',
                    borderRadius: 6,
                    fontSize: '0.75rem',
                    fontWeight: 700
                }}>
                    {exCase.priority} Priority
                </span>
                {exCase.requiresLegalReview && (
                    <span style={{
                        background: '#dc262620',
                        color: '#dc2626',
                        padding: '4px 8px',
                        borderRadius: 6,
                        fontSize: '0.75rem',
                        fontWeight: 700
                    }}>
                        ⚖️ Legal Review
                    </span>
                )}
                {exCase.requiresComplianceReview && (
                    <span style={{
                        background: '#eab30820',
                        color: '#eab308',
                        padding: '4px 8px',
                        borderRadius: 6,
                        fontSize: '0.75rem',
                        fontWeight: 700
                    }}>
                        📋 Compliance Review
                    </span>
                )}
            </div>

            {/* Timeline View style for status actions */}
            <div style={{ marginTop: 'auto', paddingTop: 15, borderTop: '1px solid rgba(255,255,255,0.05)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                    Created: <strong style={{ color: 'var(--text-main)' }}>{new Date(exCase.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</strong>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    {exCase.status === 'PENDING' && (
                        <button className="primary-btn" style={{ fontSize: '0.75rem', padding: '6px 14px', background: '#3b82f6', borderColor: '#3b82f6' }} onClick={(e) => { e.stopPropagation(); onClick(); }}>Investigate</button>
                    )}
                    {exCase.status === 'UNDER_REVIEW' && (
                        <button className="primary-btn" style={{ fontSize: '0.75rem', padding: '6px 14px', background: '#eab308', borderColor: '#eab308', color: '#020617' }} onClick={(e) => { e.stopPropagation(); onClick(); }}>Escalate</button>
                    )}
                    {(exCase.status === 'RESOLVED' || exCase.status === 'CLOSED') && (
                        <button className="secondary-btn" style={{ fontSize: '0.75rem', padding: '6px 14px' }} onClick={(e) => { e.stopPropagation(); onClick(); }}>View Log</button>
                    )}
                </div>
            </div>
        </motion.div>
    );
}

function ExceptionCaseModal({ exCase, onClose, onUpdate, adminId }) {
    const { notify } = useNotification();
    const [resolution, setResolution] = useState('');
    const [actionTaken, setActionTaken] = useState('APPROVED');
    const [resolving, setResolving] = useState(false);

    const handleResolve = async () => {
        if (!resolution.trim()) {
            notify("Please provide a resolution", "error");
            return;
        }

        setResolving(true);
        try {
            await api.put(`/admin/exceptions/${exCase.caseId}/resolve`, {
                resolution,
                actionTaken
            });
            notify("Exception case resolved successfully", "success");
            onUpdate();
            onClose();
        } catch (err) {
            console.error(err);
            notify("Failed to resolve case", "error");
        } finally {
            setResolving(false);
        }
    };

    return (
        <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            background: "rgba(0,0,0,0.6)", backdropFilter: "blur(5px)",
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2000,
            padding: 20,
            overflowY: 'auto'
        }}>
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="card"
                style={{ width: 800, maxWidth: "100%", maxHeight: '90vh', overflowY: 'auto' }}
            >
                <h2 style={{ marginTop: 0 }}>Exception Case Details</h2>

                {/* Case Header */}
                <div className="card" style={{ background: 'rgba(0,0,0,0.03)', marginBottom: 20 }}>
                    <h3 style={{ marginTop: 0 }}>{exCase.title}</h3>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 }}>
                        <span style={{
                            background: 'var(--primary)20',
                            color: 'var(--primary)',
                            padding: '6px 12px',
                            borderRadius: 8,
                            fontSize: '0.85rem',
                            fontWeight: 700
                        }}>
                            {exCase.caseType.replace('_', ' ')}
                        </span>
                        <span style={{
                            background: '#eab30820',
                            color: '#eab308',
                            padding: '6px 12px',
                            borderRadius: 8,
                            fontSize: '0.85rem',
                            fontWeight: 700
                        }}>
                            {exCase.priority} Priority
                        </span>
                        <span style={{
                            background: '#3b82f620',
                            color: '#3b82f6',
                            padding: '6px 12px',
                            borderRadius: 8,
                            fontSize: '0.85rem',
                            fontWeight: 700
                        }}>
                            {exCase.status}
                        </span>
                    </div>
                </div>

                {/* Parties */}
                <div className="card" style={{ background: 'rgba(0,0,0,0.03)', marginBottom: 20 }}>
                    <h3 style={{ marginTop: 0, fontSize: '1.1rem' }}>Parties Involved</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 15 }}>
                        <div>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6, marginBottom: 4 }}>USER</div>
                            <div style={{ fontWeight: 600 }}>{exCase.userName}</div>
                            <div style={{ fontSize: '0.85rem', opacity: 0.7 }}>{exCase.userEmail}</div>
                        </div>
                        <div>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6, marginBottom: 4 }}>AGENT</div>
                            <div style={{ fontWeight: 600 }}>{exCase.agentName}</div>
                            <div style={{ fontSize: '0.85rem', opacity: 0.7 }}>{exCase.agentEmail}</div>
                        </div>
                    </div>
                    {exCase.policyName && (
                        <div style={{ marginTop: 15, paddingTop: 15, borderTop: '1px solid var(--card-border)' }}>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6, marginBottom: 4 }}>POLICY</div>
                            <div style={{ fontWeight: 600 }}>{exCase.policyName}</div>
                        </div>
                    )}
                </div>

                {/* Description */}
                <div style={{ marginBottom: 20 }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Description</h3>
                    <div className="card" style={{ background: 'rgba(0,0,0,0.03)' }}>
                        <p style={{ margin: 0, lineHeight: 1.6 }}>{exCase.description}</p>
                    </div>
                </div>

                {/* User Complaint */}
                {exCase.userComplaint && (
                    <div style={{ marginBottom: 20 }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>User Complaint</h3>
                        <div className="card" style={{ background: '#ef444410', borderLeft: '3px solid #ef4444' }}>
                            <p style={{ margin: 0, lineHeight: 1.6 }}>{exCase.userComplaint}</p>
                        </div>
                    </div>
                )}

                {/* Agent Response */}
                {exCase.agentResponse && (
                    <div style={{ marginBottom: 20 }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Agent Response</h3>
                        <div className="card" style={{ background: '#3b82f610', borderLeft: '3px solid #3b82f6' }}>
                            <p style={{ margin: 0, lineHeight: 1.6 }}>{exCase.agentResponse}</p>
                        </div>
                    </div>
                )}

                {/* Resolution Form (if not resolved) */}
                {exCase.status !== 'RESOLVED' && (
                    <div style={{ marginBottom: 20 }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: 15 }}>Resolution</h3>

                        {/* Action Taken */}
                        <div style={{ marginBottom: 15 }}>
                            <label style={{ display: 'block', marginBottom: 8, fontWeight: 600 }}>
                                Action Taken
                            </label>
                            <div style={{ display: 'flex', gap: 10 }}>
                                {['APPROVED', 'REJECTED', 'AGENT_WARNED', 'AGENT_SUSPENDED', 'POLICY_MODIFIED'].map(action => (
                                    <button
                                        key={action}
                                        onClick={() => setActionTaken(action)}
                                        style={{
                                            padding: '8px 16px',
                                            borderRadius: 8,
                                            border: actionTaken === action ? '2px solid var(--primary)' : '1px solid var(--card-border)',
                                            background: actionTaken === action ? 'var(--primary)20' : 'transparent',
                                            color: actionTaken === action ? 'var(--primary)' : 'var(--text-main)',
                                            fontWeight: actionTaken === action ? 700 : 500,
                                            cursor: 'pointer',
                                            fontSize: '0.85rem'
                                        }}
                                    >
                                        {action.replace('_', ' ')}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Resolution Text */}
                        <div>
                            <label style={{ display: 'block', marginBottom: 8, fontWeight: 600 }}>
                                Resolution Details *
                            </label>
                            <textarea
                                value={resolution}
                                onChange={e => setResolution(e.target.value)}
                                placeholder="Explain the resolution and actions taken..."
                                rows={5}
                                style={{
                                    width: '100%',
                                    padding: 10,
                                    borderRadius: 8,
                                    border: '1px solid var(--card-border)',
                                    fontFamily: 'inherit',
                                    resize: 'vertical'
                                }}
                            />
                        </div>
                    </div>
                )}

                {/* Existing Resolution (if resolved) */}
                {exCase.status === 'RESOLVED' && (
                    <div style={{ marginBottom: 20 }}>
                        <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Resolution</h3>
                        <div className="card" style={{ background: '#22c55e10', borderLeft: '3px solid #22c55e' }}>
                            <div style={{ marginBottom: 10 }}>
                                <strong>Action Taken:</strong> {exCase.actionTaken?.replace('_', ' ')}
                            </div>
                            <p style={{ margin: 0, lineHeight: 1.6 }}>{exCase.resolution}</p>
                            <div style={{ marginTop: 10, fontSize: '0.85rem', opacity: 0.7 }}>
                                Resolved by {exCase.resolvedByName} on {new Date(exCase.resolvedAt).toLocaleDateString()}
                            </div>
                        </div>
                    </div>
                )}

                {/* Actions */}
                <div style={{ display: 'flex', gap: 10 }}>
                    <button
                        className="secondary-btn"
                        onClick={onClose}
                        disabled={resolving}
                        style={{ flex: 1, padding: '12px' }}
                    >
                        Close
                    </button>
                    {exCase.status !== 'RESOLVED' && (
                        <button
                            className="primary-btn"
                            onClick={handleResolve}
                            disabled={resolving}
                            style={{ flex: 1, padding: '12px' }}
                        >
                            {resolving ? 'Resolving...' : 'Resolve Case'}
                        </button>
                    )}
                </div>
            </motion.div>
        </div>
    );
}
