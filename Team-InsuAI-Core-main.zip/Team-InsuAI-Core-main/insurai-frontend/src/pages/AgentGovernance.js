import { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import api from "../services/api";
import { useNotification } from "../context/NotificationContext";
import { useConfirm } from "../components/ConfirmDialog";
import Modal from "../components/Modal";

export default function AgentGovernance() {
    const [agents, setAgents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedAgent, setSelectedAgent] = useState(null);
    const [filter, setFilter] = useState('all'); // all, active, inactive
    const { notify } = useNotification();
    const confirm = useConfirm();

    // Deactivation Modal State
    const [isDeactivateModalOpen, setIsDeactivateModalOpen] = useState(false);
    const [agentToDeactivate, setAgentToDeactivate] = useState(null);
    const [deactivateReason, setDeactivateReason] = useState("");
    const [processingId, setProcessingId] = useState(null);

    const fetchAgents = useCallback(() => {
        setLoading(true);
        api.get('/admin/agents/governance')
            .then(r => {
                setAgents(r.data);
                setLoading(false);
            })
            .catch(err => {
                console.error(err);
                notify("Failed to load agents", "error");
                setLoading(false);
            });
    }, [notify]);

    useEffect(() => {
        fetchAgents();
    }, [fetchAgents]);

    const handleToggleStatus = async (agent) => {
        if (agent.isActive) {
            // Deactivating - Open Modal
            setAgentToDeactivate(agent);
            setDeactivateReason("");
            setIsDeactivateModalOpen(true);
        } else {
            // Activating - Do directly
            setProcessingId(agent.agentId);
            try {
                await api.put(`/admin/agents/${agent.agentId}/status`, {
                    isActive: true,
                    reason: null
                });
                notify(`Agent activated successfully`, "success");
                fetchAgents();
            } catch (err) {
                console.error(err);
                notify("Failed to activate agent", "error");
            } finally {
                setProcessingId(null);
            }
        }
    };

    const handleDeleteAgent = async (agent) => {
        const ok = await confirm({
            title: `Delete Agent`,
            message: `Are you sure you want to permanently delete ${agent.agentName}? This will remove all their data, assignments, and consultation history.`,
            detail: `⚠️ This action is irreversible and cannot be undone.`,
            confirmLabel: "Yes, Delete Agent",
            cancelLabel: "Cancel",
            variant: "danger",
        });
        if (!ok) return;
        setProcessingId(agent.agentId);
        try {
            await api.delete(`/admin/users/${agent.agentId}`);
            notify(`Agent ${agent.agentName} deleted successfully`, "success");
            fetchAgents();
        } catch (err) {
            console.error(err);
            notify(err.response?.data?.message || "Failed to delete agent", "error");
        } finally {
            setProcessingId(null);
        }
    };

    const confirmDeactivation = async () => {
        if (!deactivateReason.trim()) {
            notify("Deactivation reason is required", "error");
            return;
        }

        const agent = agentToDeactivate;
        setProcessingId(agent.agentId);
        setIsDeactivateModalOpen(false);

        try {
            await api.put(`/admin/agents/${agent.agentId}/status`, {
                isActive: false,
                reason: deactivateReason
            });
            notify(`Agent deactivated successfully`, "success");
            fetchAgents();
        } catch (err) {
            console.error(err);
            notify("Failed to deactivate agent", "error");
        } finally {
            setProcessingId(null);
            setAgentToDeactivate(null);
        }
    };

    const filteredAgents = agents.filter(a => {
        if (filter === 'active') return a.isActive;
        if (filter === 'inactive') return !a.isActive;
        return true;
    });

    const activeCount = agents.filter(a => a.isActive).length;
    const inactiveCount = agents.filter(a => !a.isActive).length;

    return (
        <div>
            <div style={{ marginBottom: 30 }}>
                <h1 className="text-gradient" style={{ marginBottom: 10, fontSize: "2.5rem" }}>
                    👥 Agent Governance
                </h1>
                <p style={{ opacity: 0.8 }}>
                    Manage agent assignments, monitor compliance, and control access
                </p>
            </div>

            {/* Filter Tabs */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 30 }}>
                <FilterTab
                    active={filter === 'all'}
                    onClick={() => setFilter('all')}
                    label="All Agents"
                    count={agents.length}
                />
                <FilterTab
                    active={filter === 'active'}
                    onClick={() => setFilter('active')}
                    label="Active"
                    count={activeCount}
                    color="#22c55e"
                />
                <FilterTab
                    active={filter === 'inactive'}
                    onClick={() => setFilter('inactive')}
                    label="Inactive"
                    count={inactiveCount}
                    color="#ef4444"
                />
            </div>

            {/* Agents Grid */}
            {loading ? (
                <div className="grid">
                    {Array.from({ length: 6 }).map((_, i) => (
                        <div key={i} className="card" style={{ minHeight: 250 }}>
                            <div className="skeleton" style={{ height: 20, width: "60%", marginBottom: 10 }}></div>
                            <div className="skeleton" style={{ height: 40, width: "80%", marginBottom: 20 }}></div>
                        </div>
                    ))}
                </div>
            ) : filteredAgents.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: 60 }}>
                    <div style={{ fontSize: '3rem', marginBottom: 20 }}>👤</div>
                    <h3>No {filter !== 'all' ? filter : ''} agents</h3>
                </div>
            ) : (
                <div className="grid">
                    {filteredAgents.map((agent, index) => (
                        <AgentCard
                            key={agent.agentId}
                            agent={agent}
                            index={index}
                            onClick={() => setSelectedAgent(agent)}
                            onToggleStatus={() => handleToggleStatus(agent)}
                            onDelete={() => handleDeleteAgent(agent)}
                            isProcessing={processingId === agent.agentId}
                        />
                    ))}
                </div>
            )}

            {/* Agent Detail Modal */}
            {selectedAgent && (
                <AgentDetailModal
                    agent={selectedAgent}
                    onClose={() => setSelectedAgent(null)}
                    onUpdate={fetchAgents}
                />
            )}

            {/* Deactivation Confirmation Modal */}
            <Modal
                isOpen={isDeactivateModalOpen}
                onClose={() => setIsDeactivateModalOpen(false)}
                title="Deactivate Agent"
                actions={
                    <>
                        <button className="secondary-btn" onClick={() => setIsDeactivateModalOpen(false)}>Cancel</button>
                        <button className="primary-btn" style={{ background: '#ef4444' }} onClick={confirmDeactivation}>
                            Deactivate
                        </button>
                    </>
                }
            >
                <div>
                    <p style={{ marginBottom: 15 }}>
                        Are you sure you want to deactivate <strong>{agentToDeactivate?.agentName}</strong>?
                        They will immediately lose access to the platform.
                    </p>
                    <div className="form-group">
                        <label className="form-label">Reason for Deactivation <span style={{ color: '#ef4444' }}>*</span></label>
                        <textarea
                            className="form-input"
                            rows="3"
                            value={deactivateReason}
                            onChange={(e) => setDeactivateReason(e.target.value)}
                            placeholder="e.g. Compliance violation, contract ended..."
                            autoFocus
                        />
                    </div>
                </div>
            </Modal>
        </div>
    );
}

function FilterTab({ active, onClick, label, count, color }) {
    return (
        <button
            onClick={onClick}
            style={{
                padding: '10px 20px',
                borderRadius: 8,
                border: active ? `2px solid ${color || 'var(--primary)'}` : '1px solid var(--card-border)',
                background: active ? `${color || 'var(--primary)'}10` : 'transparent',
                color: active ? (color || 'var(--primary)') : 'var(--text-main)',
                fontWeight: active ? 700 : 500,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: 8
            }}
        >
            {label}
            <span style={{
                background: active ? (color || 'var(--primary)') : 'var(--card-border)',
                color: active ? 'white' : 'var(--text-main)',
                padding: '2px 8px',
                borderRadius: 12,
                fontSize: '0.75rem',
                fontWeight: 700
            }}>
                {count}
            </span>
        </button>
    );
}

function AgentCard({ agent, index, onClick, onToggleStatus, onDelete, isProcessing }) {
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="card"
            style={{
                cursor: 'pointer',
                border: !agent.isActive ? '2px solid #ef4444' : undefined,
                opacity: !agent.isActive ? 0.7 : 1
            }}
            onClick={onClick}
        >
            {/* Status Badge */}
            <div style={{
                position: 'absolute',
                top: 10,
                right: 10,
                background: agent.isActive ? '#22c55e' : '#ef4444',
                color: 'white',
                padding: '4px 10px',
                borderRadius: 12,
                fontSize: '0.75rem',
                fontWeight: 700
            }}>
                {agent.isActive ? 'ACTIVE' : 'INACTIVE'}
            </div>

            {/* Agent Info */}
            <div style={{ marginBottom: 15, marginTop: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <div style={{
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        fontWeight: 700,
                        fontSize: '1.5rem'
                    }}>
                        {agent.agentName?.charAt(0) || 'A'}
                    </div>
                    <div>
                        <h3 style={{ margin: 0, fontSize: '1.1rem' }}>{agent.agentName}</h3>
                        <p style={{ margin: 0, fontSize: '0.85rem', opacity: 0.6 }}>{agent.agentEmail}</p>
                    </div>
                </div>
            </div>

            {/* Performance Metrics */}
            <div style={{ marginBottom: 15, padding: 10, background: 'rgba(0,0,0,0.03)', borderRadius: 8 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: '0.85rem' }}>
                    <div>
                        <div style={{ opacity: 0.6 }}>Consultations</div>
                        <div style={{ fontWeight: 700 }}>{agent.totalConsultations || 0}</div>
                    </div>
                    <div>
                        <div style={{ opacity: 0.6 }}>Pending</div>
                        <div style={{ fontWeight: 700, color: '#eab308' }}>{agent.pendingConsultations || 0}</div>
                    </div>
                    <div>
                        <div style={{ opacity: 0.6 }}>Approval Rate</div>
                        <div style={{ fontWeight: 700, color: '#22c55e' }}>
                            {agent.approvalRate ? `${agent.approvalRate.toFixed(0)}%` : 'N/A'}
                        </div>
                    </div>
                    <div>
                        <div style={{ opacity: 0.6 }}>SLA Breaches</div>
                        <div style={{ fontWeight: 700, color: agent.slaBreaches > 0 ? '#ef4444' : '#22c55e' }}>
                            {agent.slaBreaches || 0}
                        </div>
                    </div>
                </div>
            </div>

            {/* Flags */}
            {(agent.misconductFlags > 0 || agent.escalatedCases > 0) && (
                <div style={{ marginBottom: 15, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {agent.misconductFlags > 0 && (
                        <span style={{
                            background: '#ef444420',
                            color: '#ef4444',
                            padding: '4px 8px',
                            borderRadius: 6,
                            fontSize: '0.75rem',
                            fontWeight: 700
                        }}>
                            ⚠️ {agent.misconductFlags} Misconduct
                        </span>
                    )}
                    {agent.escalatedCases > 0 && (
                        <span style={{
                            background: '#eab30820',
                            color: '#eab308',
                            padding: '4px 8px',
                            borderRadius: 6,
                            fontSize: '0.75rem',
                            fontWeight: 700
                        }}>
                            📢 {agent.escalatedCases} Escalations
                        </span>
                    )}
                </div>
            )}

            {/* Actions */}
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {/* Manage */}
                <button
                    className="primary-btn"
                    style={{ flex: 2, minWidth: 80 }}
                    onClick={(e) => { e.stopPropagation(); onClick(); }}
                    disabled={isProcessing}
                >
                    Manage
                </button>

                {/* Activate / Deactivate */}
                <button
                    onClick={(e) => { e.stopPropagation(); onToggleStatus(); }}
                    disabled={isProcessing}
                    style={{
                        flex: 2,
                        minWidth: 90,
                        padding: '10px',
                        borderRadius: 8,
                        border: '1px solid var(--card-border)',
                        background: agent.isActive ? '#ef444420' : '#22c55e20',
                        color: agent.isActive ? '#ef4444' : '#22c55e',
                        fontWeight: 600,
                        cursor: 'pointer',
                        opacity: isProcessing ? 0.7 : 1
                    }}
                >
                    {isProcessing ? 'Processing...' : agent.isActive ? 'Deactivate' : 'Activate'}
                </button>

                {/* Delete */}
                <motion.button
                    whileHover={{ scale: isProcessing ? 1 : 1.06 }}
                    whileTap={{ scale: isProcessing ? 1 : 0.94 }}
                    onClick={(e) => { e.stopPropagation(); onDelete(); }}
                    disabled={isProcessing}
                    title="Permanently delete this agent"
                    style={{
                        flex: 1,
                        minWidth: 42,
                        padding: '10px',
                        borderRadius: 8,
                        border: '1px solid rgba(239,68,68,0.35)',
                        background: 'rgba(239,68,68,0.1)',
                        color: '#ef4444',
                        fontWeight: 700,
                        cursor: isProcessing ? 'not-allowed' : 'pointer',
                        opacity: isProcessing ? 0.5 : 1,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1rem',
                        transition: 'all 0.2s',
                    }}
                    onMouseEnter={e => {
                        if (!isProcessing) {
                            e.currentTarget.style.background = 'rgba(239,68,68,0.22)';
                            e.currentTarget.style.borderColor = 'rgba(239,68,68,0.6)';
                            e.currentTarget.style.boxShadow = '0 0 12px rgba(239,68,68,0.4)';
                        }
                    }}
                    onMouseLeave={e => {
                        e.currentTarget.style.background = 'rgba(239,68,68,0.1)';
                        e.currentTarget.style.borderColor = 'rgba(239,68,68,0.35)';
                        e.currentTarget.style.boxShadow = 'none';
                    }}
                >
                    {/* Custom Delete Icon: X-slash in circle */}
                    <svg
                        width="18" height="18" viewBox="0 0 20 20"
                        fill="none" xmlns="http://www.w3.org/2000/svg"
                        style={{ display: 'block' }}
                    >
                        {/* Outer ring */}
                        <circle cx="10" cy="10" r="9" stroke="#ef4444" strokeWidth="1.5" fill="rgba(239,68,68,0.12)" />
                        {/* X strokes */}
                        <line x1="6.5" y1="6.5" x2="13.5" y2="13.5" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" />
                        <line x1="13.5" y1="6.5" x2="6.5" y2="13.5" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                </motion.button>
            </div>
        </motion.div>
    );
}

function AgentDetailModal({ agent, onClose, onUpdate }) {
    const { notify } = useNotification();
    const [regions, setRegions] = useState(agent.assignedRegions || []);
    const [policyTypes, setPolicyTypes] = useState(agent.assignedPolicyTypes || []);
    const [saving, setSaving] = useState(false);

    const availableRegions = ['North', 'South', 'East', 'West', 'Central'];
    const availablePolicyTypes = [
        'Health', 'Life', 'Child', 'Accident', 'Critical', 'Family', 'Senior', 'OPD', 'Top-Up', 'Wellness',
        'Endowment', 'Money Back', 'Guaranteed', 'Pension', 'ULIP', 'Investment', 'Property', 'Group Health',
        'Group Life', 'Cyber', 'Motor', 'Home', 'Travel'
    ];

    const handleSaveAssignments = async () => {
        setSaving(true);
        try {
            await api.put(`/admin/agents/${agent.agentId}/assignments`, {
                regions,
                policyTypes
            });
            notify("Agent assignments updated successfully", "success");
            onUpdate();
            onClose();
        } catch (err) {
            console.error(err);
            notify("Failed to update assignments", "error");
        } finally {
            setSaving(false);
        }
    };

    const toggleRegion = (region) => {
        setRegions(prev =>
            prev.includes(region) ? prev.filter(r => r !== region) : [...prev, region]
        );
    };

    const togglePolicyType = (type) => {
        setPolicyTypes(prev =>
            prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
        );
    };

    return (
        <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            background: "rgba(0,0,0,0.6)", backdropFilter: "blur(5px)",
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2000,
            padding: 20,
            overflowY: 'auto'
        }}>
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="card"
                style={{ width: 700, maxWidth: "100%", maxHeight: '90vh', overflowY: 'auto' }}
            >
                <h2 style={{ marginTop: 0 }}>Agent Management</h2>

                {/* Agent Info */}
                <div className="card" style={{ background: 'rgba(0,0,0,0.03)', marginBottom: 20 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 15, marginBottom: 15 }}>
                        <div style={{
                            width: 60,
                            height: 60,
                            borderRadius: '50%',
                            background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: 'white',
                            fontWeight: 700,
                            fontSize: '1.8rem'
                        }}>
                            {agent.agentName?.charAt(0) || 'A'}
                        </div>
                        <div>
                            <h3 style={{ margin: 0 }}>{agent.agentName}</h3>
                            <p style={{ margin: 0, opacity: 0.7 }}>{agent.agentEmail}</p>
                            <div style={{
                                marginTop: 5,
                                padding: '4px 10px',
                                background: agent.isActive ? '#22c55e20' : '#ef444420',
                                color: agent.isActive ? '#22c55e' : '#ef4444',
                                borderRadius: 12,
                                fontSize: '0.75rem',
                                fontWeight: 700,
                                display: 'inline-block'
                            }}>
                                {agent.isActive ? 'ACTIVE' : 'INACTIVE'}
                            </div>
                        </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
                        <div>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6 }}>Total Consultations</div>
                            <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>{agent.totalConsultations || 0}</div>
                        </div>
                        <div>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6 }}>Approval Rate</div>
                            <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#22c55e' }}>
                                {agent.approvalRate ? `${agent.approvalRate.toFixed(0)}%` : 'N/A'}
                            </div>
                        </div>
                        <div>
                            <div style={{ fontSize: '0.75rem', opacity: 0.6 }}>SLA Breaches</div>
                            <div style={{ fontSize: '1.2rem', fontWeight: 700, color: agent.slaBreaches > 0 ? '#ef4444' : '#22c55e' }}>
                                {agent.slaBreaches || 0}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Assigned Regions */}
                <div style={{ marginBottom: 20 }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Assigned Regions</h3>
                    <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                        {availableRegions.map(region => (
                            <button
                                key={region}
                                onClick={() => toggleRegion(region)}
                                style={{
                                    padding: '8px 16px',
                                    borderRadius: 8,
                                    border: regions.includes(region) ? '2px solid var(--primary)' : '1px solid var(--card-border)',
                                    background: regions.includes(region) ? 'var(--primary)20' : 'transparent',
                                    color: regions.includes(region) ? 'var(--primary)' : 'var(--text-main)',
                                    fontWeight: regions.includes(region) ? 700 : 500,
                                    cursor: 'pointer'
                                }}
                            >
                                {regions.includes(region) && '✓ '}{region}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Assigned Policy Types */}
                <div style={{ marginBottom: 20 }}>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Assigned Policy Types</h3>
                    <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                        {availablePolicyTypes.map(type => (
                            <button
                                key={type}
                                onClick={() => togglePolicyType(type)}
                                style={{
                                    padding: '8px 16px',
                                    borderRadius: 8,
                                    border: policyTypes.includes(type) ? '2px solid var(--primary)' : '1px solid var(--card-border)',
                                    background: policyTypes.includes(type) ? 'var(--primary)20' : 'transparent',
                                    color: policyTypes.includes(type) ? 'var(--primary)' : 'var(--text-main)',
                                    fontWeight: policyTypes.includes(type) ? 700 : 500,
                                    cursor: 'pointer'
                                }}
                            >
                                {policyTypes.includes(type) && '✓ '}{type}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
                    <button
                        className="secondary-btn"
                        onClick={onClose}
                        disabled={saving}
                        style={{ flex: 1, padding: '12px' }}
                    >
                        Cancel
                    </button>
                    <button
                        className="primary-btn"
                        onClick={handleSaveAssignments}
                        disabled={saving}
                        style={{ flex: 1, padding: '12px' }}
                    >
                        {saving ? 'Saving...' : 'Save Assignments'}
                    </button>
                </div>
            </motion.div>
        </div>
    );
}
